# WebProxy.net
基于命令的Web访问代理进行代理

功能：

1. 基于command命令
2. 支持不同渠道代理访问不同的地址
3. 支持不同版本代理访问不同的地址
4. 支持按参数缓存代理访问的结果



## 工作日志

2017-7-31 代理配置支持多文件

2017-8-1 实现Single Command --Multiple Request 模式